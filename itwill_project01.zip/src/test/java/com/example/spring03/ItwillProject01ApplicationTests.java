package com.example.spring03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItwillProject01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
